package com.example.androidprojectcollection;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class CalculatorExercise extends AppCompatActivity {
    TextView main, sub;
    Button seven, eight, nine, slash, four, five, six, star, one, two, three, dash, dot, zero, plus, equals;
    String current_operator, current_statement, prev_statement;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator_exercise);
        main = findViewById(R.id.main_display);
        sub = findViewById(R.id.sub_display);
        one = findViewById(R.id.button_one);
        two = findViewById(R.id.button_two);
        three = findViewById(R.id.button_three);
        four = findViewById(R.id.button_four);
        five = findViewById(R.id.button_five);
        six = findViewById(R.id.button_six);
        seven = findViewById(R.id.button_seven);
        eight = findViewById(R.id.button_eight);
        nine = findViewById(R.id.button_nine);
        zero = findViewById(R.id.button_zero);
        slash = findViewById(R.id.button_slash);
        star = findViewById(R.id.button_star);
        dash = findViewById(R.id.button_dash);
        dot = findViewById(R.id.button_dot);
        plus = findViewById(R.id.button_plus);
        equals = findViewById(R.id.button_equals);
        current_operator = "0";

        slash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence main_text = main.getText();
                String main_str = main_text.toString();
                prev_statement = current_statement;
                current_statement = "0";
                if(current_operator.equals("0")) {
                    current_operator = "/";
                    main_str += current_operator;
                    main.setText(main_str);
                } else {
                    main_str = main_str.substring(0, main_str.length() - 1) + "/";
                    main.setText(main_str);
                    current_operator = "/";
                }
            }
        });

        star.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence main_text = main.getText();
                String main_str = main_text.toString();
                prev_statement = current_statement;
                current_statement = "0";
                if(current_operator.equals("0")) {
                    current_operator = "*";
                    main_str += current_operator;
                    main.setText(main_str);
                } else {
                    main_str = main_str.substring(0, main_str.length() - 1) + "*";
                    main.setText(main_str);
                    current_operator = "*";
                }
            }
        });

        dash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence main_text = main.getText();
                String main_str = main_text.toString();
                prev_statement = current_statement;
                current_statement = "0";
                if(current_operator.equals("0")) {
                    current_operator = "-";
                    main_str += current_operator;
                    main.setText(main_str);
                } else {
                    main_str = main_str.substring(0, main_str.length() - 1) + "-";
                    main.setText(main_str);
                    current_operator = "-";
                }
            }
        });

        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence main_text = main.getText();
                String main_str = main_text.toString();
                prev_statement = current_statement;
                current_statement = "0";
                if(current_operator.equals("0")) {
                    current_operator = "+";
                    main_str += current_operator;
                    main.setText(main_str);
                } else {
                    main_str = main_str.substring(0, main_str.length() - 1) + "+";
                    main.setText(main_str);
                    current_operator = "+";
                }
            }
        });

        equals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float answer;
                switch(current_operator) {
                    case "+":
                        answer = Float.parseFloat(prev_statement) + Float.parseFloat(current_statement);
                        sub.setText(String.valueOf(answer));
                        break;
                    case "-":
                        answer = Float.parseFloat(prev_statement) - Float.parseFloat(current_statement);
                        sub.setText(String.valueOf(answer));
                        break;
                    case "*":
                        answer = Float.parseFloat(prev_statement) * Float.parseFloat(current_statement);
                        sub.setText(String.valueOf(answer));
                        break;
                    case "/":
                        answer = Float.parseFloat(prev_statement) / Float.parseFloat(current_statement);
                        sub.setText(String.valueOf(answer));
                        break;
                }
            }
        });

        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence main_text = main.getText();
                String main_str = main_text.toString();
                if(Float.parseFloat(main_str) == 0) {
                    main.setText("2");
                    current_statement = "2";
                    sub.setText(current_statement);
                } else {
                    main_str += "2";
                    main.setText(main_str);
                    current_statement += "2";
                    sub.setText(current_statement);
                }
            }
        });

        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence main_text = main.getText();
                String main_str = main_text.toString();
                if(Float.parseFloat(main_str) == 0) {
                    main.setText("2");
                    current_statement = "2";
                    sub.setText(current_statement);
                } else {
                    main_str += "2";
                    main.setText(main_str);
                    current_statement += "2";
                    sub.setText(current_statement);
                }
            }
        });

        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence main_text = main.getText();
                String main_str = main_text.toString();
                if(Float.parseFloat(main_str) == 0) {
                    main.setText("3");
                    current_statement = "3";
                    sub.setText(current_statement);
                } else {
                    main_str += "3";
                    main.setText(main_str);
                    current_statement += "3";
                    sub.setText(current_statement);
                }
            }
        });

        four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence main_text = main.getText();
                String main_str = main_text.toString();
                if(Float.parseFloat(main_str) == 0) {
                    main.setText("4");
                    current_statement = "4";
                    sub.setText(current_statement);
                } else {
                    main_str += "4";
                    main.setText(main_str);
                    current_statement += "4";
                    sub.setText(current_statement);
                }
            }
        });

        five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence main_text = main.getText();
                String main_str = main_text.toString();
                if(Float.parseFloat(main_str) == 0) {
                    main.setText("5");
                    current_statement = "5";
                    sub.setText(current_statement);
                } else {
                    main_str += "5";
                    main.setText(main_str);
                    current_statement += "5";
                    sub.setText(current_statement);
                }
            }
        });

        six.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence main_text = main.getText();
                String main_str = main_text.toString();
                if(Float.parseFloat(main_str) == 0) {
                    main.setText("6");
                    current_statement = "6";
                    sub.setText(current_statement);
                } else {
                    main_str += "6";
                    main.setText(main_str);
                    current_statement += "6";
                    sub.setText(current_statement);
                }
            }
        });

        seven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence main_text = main.getText();
                String main_str = main_text.toString();
                if(Float.parseFloat(main_str) == 0) {
                    main.setText("7");
                    current_statement = "7";
                    sub.setText(current_statement);
                } else {
                    main_str += "7";
                    main.setText(main_str);
                    current_statement += "7";
                    sub.setText(current_statement);
                }
            }
        });

        eight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence main_text = main.getText();
                String main_str = main_text.toString();
                if(Float.parseFloat(main_str) == 0) {
                    main.setText("8");
                    current_statement = "8";
                    sub.setText(current_statement);
                } else {
                    main_str += "8";
                    main.setText(main_str);
                    current_statement += "8";
                    sub.setText(current_statement);
                }
            }
        });

        nine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence main_text = main.getText();
                String main_str = main_text.toString();
                if(Float.parseFloat(main_str) == 0) {
                    main.setText("9");
                    current_statement = "9";
                    sub.setText(current_statement);
                } else {
                    main_str += "9";
                    main.setText(main_str);
                    current_statement += "9";
                    sub.setText(current_statement);
                }
            }
        });

        zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence main_text = main.getText();
                String main_str = main_text.toString();
                if(Float.parseFloat(main_str) != 0) {
                    main_str += "0";
                    main.setText(main_str);
                    current_statement += "0";
                    sub.setText(current_statement);
                }
            }
        });
    }
}