package com.example.androidprojectcollection;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnLayoutExercise, btnButtonExercise, btnCalculatorExercise, btnMidterm, btnPassingIntents;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLayoutExercise = findViewById(R.id.btn_LayoutExercise);
        btnLayoutExercise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, LayoutExercise.class);
                startActivity(intent);
            }
        });

        btnButtonExercise = findViewById(R.id.btn_ButtonExericse);
        btnButtonExercise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ButtonExercise.class);
                startActivity(intent);
            }
        });

        btnCalculatorExercise = findViewById(R.id.btn_CalculatorExercise);
        btnCalculatorExercise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CalculatorExercise.class);
                startActivity(intent);
            }
        });

        btnMidterm = findViewById(R.id.btn_Midterm);
        btnMidterm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ColorMatching.class);
                startActivity(intent);
            }
        });

        btnPassingIntents = findViewById(R.id.btn_PassingIntents);
        btnPassingIntents.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, PassingIntents.class);
                startActivity(intent);
            }
        });
    }
}