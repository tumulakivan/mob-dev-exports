package com.example.androidprojectcollection;

import java.util.ArrayList;
import java.util.Random;
import androidx.appcompat.app.AppCompatActivity;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ColorMatching extends AppCompatActivity {
    private Button top_left, top, top_right, left, center, right, bottom_left, bottom, bottom_right, reset, win;
    private int top_left_state, top_state, top_right_state, left_state, center_state, right_state, bottom_left_state, bottom_state, bottom_right_state;
    private ArrayList<ColorStateList> colors;
    private ColorStateList gold, purple, teal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color_matching);

        Random r = new Random();

        // setting colors to use
        gold = ColorStateList.valueOf(getColor(R.color.gold));
        purple = ColorStateList.valueOf(getColor(R.color.purple_500));
        teal = ColorStateList.valueOf(getColor(R.color.teal_200));
        colors = new ArrayList<>();
        colors.add(purple);
        colors.add(gold);
        colors.add(teal);

        // setting button ids
        top_left = findViewById(R.id.TOP_LEFT);
        top = findViewById(R.id.TOP);
        top_right = findViewById(R.id.TOP_RIGHT);
        left = findViewById(R.id.LEFT);
        center = findViewById(R.id.CENTER);
        right = findViewById(R.id.RIGHT);
        bottom_left = findViewById(R.id.BOTTOM_LEFT);
        bottom = findViewById(R.id.BOTTOM);
        bottom_right = findViewById(R.id.BOTTOM_RIGHT);
        reset = findViewById(R.id.reset);
        win = findViewById(R.id.win);

        // initialize indices for changing color states
        top_left_state = r.nextInt(3);
        top_state = r.nextInt(3);
        top_right_state = r.nextInt(3);
        left_state = r.nextInt(3);
        center_state = r.nextInt(3);
        right_state = r.nextInt(3);
        bottom_left_state = r.nextInt(3);
        bottom_state = r.nextInt(3);
        bottom_right_state = r.nextInt(3);
        center.setBackgroundTintList(colors.get(center_state));
        left.setBackgroundTintList(colors.get(left_state));
        top_left.setBackgroundTintList(colors.get(top_left_state));
        top.setBackgroundTintList(colors.get(top_state));
        top_right.setBackgroundTintList(colors.get(top_right_state));
        right.setBackgroundTintList(colors.get(right_state));
        bottom_right.setBackgroundTintList(colors.get(bottom_right_state));
        bottom_left.setBackgroundTintList(colors.get(bottom_left_state));
        bottom.setBackgroundTintList(colors.get(bottom_state));

        win.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                top_left_state = 0;
                top_state = 2;
                top_right_state = 0;
                left_state = 2;
                center_state = 0;
                right_state = 2;
                bottom_left_state = 0;
                bottom_state = 2;
                bottom_right_state = 0;
                center.setBackgroundTintList(colors.get(center_state));
                left.setBackgroundTintList(colors.get(left_state));
                top_left.setBackgroundTintList(colors.get(top_left_state));
                top.setBackgroundTintList(colors.get(top_state));
                top_right.setBackgroundTintList(colors.get(top_right_state));
                right.setBackgroundTintList(colors.get(right_state));
                bottom_right.setBackgroundTintList(colors.get(bottom_right_state));
                bottom_left.setBackgroundTintList(colors.get(bottom_left_state));
                bottom.setBackgroundTintList(colors.get(bottom_state));
            }
        });

        top_left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // set the color like this on click
                // top_left.setBackgroundTintList(colors.get(0));
                top_left_state++;
                top_state++;
                left_state++;
                if(top_left_state > 2) top_left_state = 0;
                if(top_state > 2) top_state = 0;
                if(left_state > 2) left_state = 0;
                top_left.setBackgroundTintList(colors.get(top_left_state));
                top.setBackgroundTintList(colors.get(top_state));
                left.setBackgroundTintList(colors.get(left_state));
            }
        });

        top.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                top_state++;
                top_left_state++;
                top_right_state++;
                center_state++;
                if(top_state > 2) top_state = 0;
                if(top_left_state > 2) top_left_state = 0;
                if(top_right_state > 2) top_right_state = 0;
                if(center_state > 2) center_state = 0;
                top.setBackgroundTintList(colors.get(top_state));
                top_left.setBackgroundTintList(colors.get(top_left_state));
                top_right.setBackgroundTintList(colors.get(top_right_state));
                center.setBackgroundTintList(colors.get(center_state));
            }
        });

        top_right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // set the color like this on click
                // top_left.setBackgroundTintList(colors.get(0));
                top_right_state++;
                top_state++;
                right_state++;
                if(top_right_state > 2) top_right_state = 0;
                if(top_state > 2) top_state = 0;
                if(right_state > 2) right_state = 0;
                top_right.setBackgroundTintList(colors.get(top_right_state));
                top.setBackgroundTintList(colors.get(top_state));
                right.setBackgroundTintList(colors.get(right_state));
            }
        });

        left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                left_state++;
                top_left_state++;
                center_state++;
                bottom_left_state++;
                if(left_state > 2) left_state = 0;
                if(top_left_state > 2) top_left_state = 0;
                if(center_state > 2) center_state = 0;
                if(bottom_left_state > 2) bottom_left_state = 0;
                left.setBackgroundTintList(colors.get(left_state));
                top_left.setBackgroundTintList(colors.get(top_left_state));
                center.setBackgroundTintList(colors.get(center_state));
                bottom_left.setBackgroundTintList(colors.get(bottom_left_state));
            }
        });

        center.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                center_state++;
                left_state++;
                top_state++;
                right_state++;
                bottom_state++;
                if(center_state > 2) center_state = 0;
                if(left_state > 2) left_state = 0;
                if(top_state > 2) top_state = 0;
                if(right_state > 2) right_state = 0;
                if(bottom_state > 2) bottom_state = 0;
                center.setBackgroundTintList(colors.get(center_state));
                left.setBackgroundTintList(colors.get(left_state));
                top.setBackgroundTintList(colors.get(top_state));
                right.setBackgroundTintList(colors.get(right_state));
                bottom.setBackgroundTintList(colors.get(bottom_state));
            }
        });

        right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                right_state++;
                center_state++;
                top_right_state++;
                bottom_right_state++;
                if(right_state > 2) right_state = 0;
                if(center_state > 2) center_state = 0;
                if(top_right_state > 2) top_right_state = 0;
                if(bottom_right_state > 2) bottom_right_state = 0;
                right.setBackgroundTintList(colors.get(right_state));
                center.setBackgroundTintList(colors.get(center_state));
                top_right.setBackgroundTintList(colors.get(top_right_state));
                bottom_right.setBackgroundTintList(colors.get(bottom_right_state));
            }
        });

        bottom_left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottom_left_state++;
                left_state++;
                bottom_state++;
                if(bottom_left_state > 2) bottom_left_state = 0;
                if(left_state > 2) left_state = 0;
                if(bottom_state > 2) bottom_state = 0;
                bottom_left.setBackgroundTintList(colors.get(bottom_left_state));
                left.setBackgroundTintList(colors.get(left_state));
                bottom.setBackgroundTintList(colors.get(bottom_state));
            }
        });

        bottom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottom_state++;
                bottom_left_state++;
                center_state++;
                bottom_right_state++;
                if(bottom_state > 2) bottom_state = 0;
                if(bottom_left_state > 2) bottom_left_state = 0;
                if(center_state > 2) center_state = 0;
                if(bottom_right_state > 2) bottom_right_state = 0;
                bottom.setBackgroundTintList(colors.get(bottom_state));
                bottom_left.setBackgroundTintList(colors.get(bottom_left_state));
                center.setBackgroundTintList(colors.get(center_state));
                bottom_right.setBackgroundTintList(colors.get(bottom_right_state));
            }
        });

        bottom_right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // set the color like this on click
                // top_left.setBackgroundTintList(colors.get(0));
                bottom_right_state++;
                bottom_state++;
                right_state++;
                if(bottom_right_state > 2) bottom_right_state = 0;
                if(bottom_state > 2) bottom_state = 0;
                if(right_state > 2) right_state = 0;
                bottom_right.setBackgroundTintList(colors.get(bottom_right_state));
                bottom.setBackgroundTintList(colors.get(bottom_state));
                right.setBackgroundTintList(colors.get(right_state));
            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                top_left_state = r.nextInt(3);
                top_state = r.nextInt(3);
                top_right_state = r.nextInt(3);
                left_state = r.nextInt(3);
                center_state = r.nextInt(3);
                right_state = r.nextInt(3);
                bottom_left_state = r.nextInt(3);
                bottom_state = r.nextInt(3);
                bottom_right_state = r.nextInt(3);
                center.setBackgroundTintList(colors.get(center_state));
                left.setBackgroundTintList(colors.get(left_state));
                top_left.setBackgroundTintList(colors.get(top_left_state));
                top.setBackgroundTintList(colors.get(top_state));
                top_right.setBackgroundTintList(colors.get(top_right_state));
                right.setBackgroundTintList(colors.get(right_state));
                bottom_right.setBackgroundTintList(colors.get(bottom_right_state));
                bottom_left.setBackgroundTintList(colors.get(bottom_left_state));
                bottom.setBackgroundTintList(colors.get(bottom_state));
            }
        });
    }
}