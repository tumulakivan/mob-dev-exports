package com.example.androidprojectcollection;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class PassingIntents extends AppCompatActivity {
    private Button clear, submit;
    private EditText fName_field, lName_field, birthday_field, phone_field, email_field, partner_field, hobby_field, food_field, drink_field, genre_field;
    private RadioButton male, female, others;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passing_intents);
        String fName, lName, gender, birthday, phone, email, partner, hobby, food, drink, genre;

        fName_field = findViewById(R.id.fName_field);
        lName_field = findViewById(R.id.lName_field);
        male = findViewById(R.id.choice_male);
        female = findViewById(R.id.choice_female);
        others = findViewById(R.id.choice_others);
        birthday_field = findViewById(R.id.txt_birthday);
        phone_field = findViewById(R.id.txt_phone);
        email_field = findViewById(R.id.txt_email);
        partner_field = findViewById(R.id.txt_partner);
        hobby_field = findViewById(R.id.txt_hobby);
        food_field = findViewById(R.id.txt_food);
        drink_field = findViewById(R.id.txt_drink);
        genre_field = findViewById(R.id.txt_genre);

        fName = fName_field.getText().toString();
        lName = lName_field.getText().toString();

        if(male.isChecked())
            gender = "Male";
    }
}