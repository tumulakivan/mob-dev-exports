package com.example.androidprojectcollection;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ButtonExercise extends AppCompatActivity {

    Button btnClose, btnToast, btnChangeBG, btnChangeButtonColor, btnDisappear;
    int currentBgIndex = 0, currentButtonBgIndex = 0;
    int[] bgImage = {R.drawable._42ad68b315b0f586c30b465221da609, R.drawable.hd_wallpaper_polyphia_custom_metal_rock};
    int[] buttonColor = {R.color.purple_500, R.color.black};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_button_exercise);

        btnClose = findViewById(R.id.btnClose);
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent close = new Intent(ButtonExercise.this, MainActivity.class);
                startActivity(close);
            }
        });

        btnToast = findViewById(R.id.btnToast);
        btnToast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ButtonExercise.this, "THIS IS A TOAST TEXT", Toast.LENGTH_LONG).show();
            }
        });

        btnChangeBG = findViewById(R.id.btnChangeBG);
        btnChangeBG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                findViewById(R.id.activityLayout).setBackgroundResource(bgImage[currentBgIndex]);
                if(currentBgIndex == 0) currentBgIndex = 1;
                else currentBgIndex = 0;
            }
        });

        btnChangeButtonColor = findViewById(R.id.btnChangeButtonColor);
        btnChangeButtonColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnChangeButtonColor.setBackgroundTintList(getResources().getColorStateList(buttonColor[currentButtonBgIndex]));
                if(currentButtonBgIndex == 0) currentButtonBgIndex = 1;
                else currentButtonBgIndex = 0;
            }
        });

        btnDisappear = findViewById(R.id.btnDisappear);
        btnDisappear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(btnDisappear.getVisibility() == View.VISIBLE) btnDisappear.setVisibility(View.INVISIBLE);
                else btnDisappear.setVisibility(View.VISIBLE);
            }
        });
    }
}