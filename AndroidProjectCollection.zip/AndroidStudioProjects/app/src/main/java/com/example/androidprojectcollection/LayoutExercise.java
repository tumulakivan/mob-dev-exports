package com.example.androidprojectcollection;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class LayoutExercise extends AppCompatActivity {
    private boolean home_state = true;
    private boolean search_state = false;
    private boolean add_state = false;
    private boolean notification_state = false;
    private boolean profile_state = false;
    private boolean liked = false;
    private boolean bookmarked = false;
    private String num_likes;
    private int likes = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layout_exercise);
        ImageView home = findViewById(R.id.imageView9);
        ImageView search = findViewById(R.id.imageView11);
        ImageView add = findViewById(R.id.imageView12);
        ImageView notifications = findViewById(R.id.imageView13);
        ImageView profile = findViewById(R.id.imageView14);
        ImageView like = findViewById(R.id.imageView3);
        ImageView bookmark = findViewById(R.id.imageView10);
        TextView like_ctr = findViewById(R.id.likes);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!home_state) {
                    home_state = true;
                    search_state = false;
                    add_state = false;
                    notification_state = false;
                    profile_state = false;
                }
            }
        });

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!search_state) {
                    home_state = false;
                    search_state = true;
                    add_state = false;
                    notification_state = false;
                    profile_state = false;
                }
            }
        });

        bookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!bookmarked) {
                    int color = Color.parseColor("#ffb53d");
                    bookmark.setColorFilter(color);
                    bookmark.setImageResource(R.drawable.icons8_bookmark_24__1_);
                } else {
                    int color = Color.parseColor("#000000");
                    bookmark.setColorFilter(color);
                    bookmark.setImageResource(R.drawable.icons8_bookmark_24);
                }

                bookmarked = !bookmarked;
            }
        });


        like.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               if(!liked) {
                   int color = Color.parseColor("#ff3d50");
                   like.setColorFilter(color);
                   like.setImageResource(R.drawable.icons8_heart_30__1_);
                   likes++;
               } else {
                   int color = Color.parseColor("#000000");
                   like.setColorFilter(color);
                   like.setImageResource(R.drawable.icons8_heart_30);
                   likes--;
               }

               if(likes == 0 || likes > 1) {
                   num_likes = String.valueOf(likes) + " likes";
                   like_ctr.setText(num_likes);
               } else {
                   num_likes = String.valueOf(likes) + " like";
                   like_ctr.setText(num_likes);
               }

               liked = !liked;
           }
        });

        if(!home_state) {
            home.setImageResource(R.drawable.icons8_home_24);
        } else home.setImageResource(R.drawable.icons8_home_24__1_);
    }
}