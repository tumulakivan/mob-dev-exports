package com.example.androidprojectcollection;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class LayoutExercise extends AppCompatActivity {
    private boolean liked = false;
    private boolean bookmarked = false;
    private String num_likes;
    private int likes = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layout_exercise);

        ImageView like = findViewById(R.id.imageView3);
        ImageView bookmark = findViewById(R.id.imageView10);
        TextView like_ctr = findViewById(R.id.likes);

        bookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!bookmarked) {
                    bookmark.setImageResource(R.drawable.icons8_bookmark_24__1_);
                } else {
                    bookmark.setImageResource(R.drawable.icons8_bookmark_24);
                }

                bookmarked = !bookmarked;
            }
        });


        like.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               if(!liked) {
                   like.setImageResource(R.drawable.icons8_heart_30__1_);
                   likes++;
               } else {
                   like.setImageResource(R.drawable.icons8_heart_30);
                   likes--;
               }

               if(likes == 0 || likes > 1) {
                   num_likes = String.valueOf(likes) + " likes";
                   like_ctr.setText(num_likes);
               } else {
                   num_likes = String.valueOf(likes) + " like";
                   like_ctr.setText(num_likes);
               }

               liked = !liked;
           }
        });
    }
}